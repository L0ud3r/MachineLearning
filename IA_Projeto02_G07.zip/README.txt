Autores:
João Apresentação 21152
Pedro Simões 21140
Gonçalo Cunha 21140

Docente: Joaquim Silva
Unidade Curricular: Inteligência Artificial

Dataset: Iris Species
Projeto: classificação, clustering e regras de associação da dataset lida recorrendo a algoritmos de Machine Learning.

Nota: Adicionar dataset (Iris.csv) ao Local Workflow